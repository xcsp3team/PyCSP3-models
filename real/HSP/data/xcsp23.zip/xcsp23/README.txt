Data files used for the 2023 XCSP3 Compeitition
