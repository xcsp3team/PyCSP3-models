Data files used for the 2022 XCSP3 Compeitition

Use: python EchelonStock2.py -data=<datafile.txt> -parser=EchelonStock_Parser.py
