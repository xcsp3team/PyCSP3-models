Data files used for the 2022 XCSP3 Competition
