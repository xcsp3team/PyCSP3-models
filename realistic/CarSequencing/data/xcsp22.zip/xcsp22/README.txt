Data files used for the 2022 XCSP3 Compeitition

Use: python CarSequencing.py -data=<datafile.txt> -parser=CarSequencing_Parser.py
