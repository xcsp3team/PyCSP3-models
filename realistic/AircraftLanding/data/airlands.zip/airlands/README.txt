The 13 data files come from http://people.brunel.ac.uk/~mastjjb/jeb/orlib/airlandinfo.html

Use: python AircraftLanding.py -data=<airlands/datafile.txt> -parser=AircraftLanding_Parser.py
