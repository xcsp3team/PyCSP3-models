%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 50
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 525, [], [], 'fam1', 1 ).
test( 't2', 695, [], [], 'fam1', 1 ).
test( 't3', 432, [], ['r3','r5','r4'], 'fam1', 1 ).
test( 't4', 62, [], [], 'fam1', 1 ).
test( 't5', 412, [], [], 'fam1', 1 ).
test( 't6', 799, [], [], 'fam1', 1 ).
test( 't7', 635, [], ['r5','r4','r2','r3','r1'], 'fam1', 1 ).
test( 't8', 25, [], [], 'fam1', 1 ).
test( 't9', 700, ['m2','m6','m38'], ['r2','r5','r4','r1'], 'fam1', 1 ).
test( 't10', 40, [], [], 'fam1', 1 ).
test( 't11', 801, [], [], 'fam1', 1 ).
test( 't12', 258, [], [], 'fam1', 1 ).
test( 't13', 572, [], [], 'fam1', 1 ).
test( 't14', 85, ['m5','m29','m28','m37','m27','m38','m6','m21','m9','m34'], [], 'fam1', 1 ).
test( 't15', 86, [], [], 'fam1', 1 ).
test( 't16', 591, [], [], 'fam1', 1 ).
test( 't17', 153, ['m29','m16','m3','m8','m44','m48','m34','m13','m49','m11','m28','m2','m39','m18'], [], 'fam1', 1 ).
test( 't18', 65, [], ['r4','r1','r2','r5','r3'], 'fam1', 1 ).
test( 't19', 104, [], [], 'fam1', 1 ).
test( 't20', 201, ['m21','m23','m41','m31','m44','m33','m10','m13','m17'], [], 'fam1', 1 ).
test( 't21', 149, [], [], 'fam1', 1 ).
test( 't22', 57, [], [], 'fam1', 1 ).
test( 't23', 61, [], [], 'fam1', 1 ).
test( 't24', 776, [], ['r5','r2','r3'], 'fam1', 1 ).
test( 't25', 667, [], ['r5'], 'fam1', 1 ).
test( 't26', 100, [], [], 'fam1', 1 ).
test( 't27', 326, [], [], 'fam1', 1 ).
test( 't28', 171, [], ['r2'], 'fam1', 1 ).
test( 't29', 187, [], [], 'fam1', 1 ).
test( 't30', 104, [], [], 'fam1', 1 ).
test( 't31', 765, [], [], 'fam1', 1 ).
test( 't32', 650, [], [], 'fam1', 1 ).
test( 't33', 212, [], ['r2','r3','r5','r1','r4'], 'fam1', 1 ).
test( 't34', 263, [], ['r4','r3','r1','r2','r5'], 'fam1', 1 ).
test( 't35', 749, ['m48','m11','m49','m25','m23','m17','m41','m29','m32','m2','m16','m4','m8','m5','m21'], [], 'fam1', 1 ).
test( 't36', 523, [], ['r1','r3'], 'fam1', 1 ).
test( 't37', 717, ['m38','m49','m48','m11','m9','m30'], [], 'fam1', 1 ).
test( 't38', 628, [], [], 'fam1', 1 ).
test( 't39', 288, [], ['r4'], 'fam1', 1 ).
test( 't40', 732, [], [], 'fam1', 1 ).
test( 't41', 28, ['m23','m1','m42','m43','m26','m33','m45','m27','m25','m48','m39','m37','m17','m14','m49','m5','m36','m50'], [], 'fam1', 1 ).
test( 't42', 89, [], [], 'fam1', 1 ).
test( 't43', 690, [], [], 'fam1', 1 ).
test( 't44', 646, ['m18','m39','m29','m19','m24','m30'], ['r4','r1'], 'fam1', 1 ).
test( 't45', 619, [], [], 'fam1', 1 ).
test( 't46', 328, ['m8','m15','m32','m37','m18','m34','m27','m47','m10','m30','m24','m2','m49','m38','m13','m26','m11','m40','m41','m9'], ['r3'], 'fam1', 1 ).
test( 't47', 621, ['m20','m6','m29','m34','m3','m19'], [], 'fam1', 1 ).
test( 't48', 566, [], [], 'fam1', 1 ).
test( 't49', 679, [], [], 'fam1', 1 ).
test( 't50', 46, [], ['r1','r2'], 'fam1', 1 ).
test( 't51', 717, [], [], 'fam1', 1 ).
test( 't52', 241, [], [], 'fam1', 1 ).
test( 't53', 210, ['m18','m20','m50'], [], 'fam1', 1 ).
test( 't54', 722, ['m5','m32','m31','m25','m22','m6','m29','m23','m13','m48','m15','m1','m40','m18','m38','m11','m24','m19'], [], 'fam1', 1 ).
test( 't55', 26, [], ['r3'], 'fam1', 1 ).
test( 't56', 720, [], [], 'fam1', 1 ).
test( 't57', 797, [], [], 'fam1', 1 ).
test( 't58', 770, [], [], 'fam1', 1 ).
test( 't59', 767, [], [], 'fam1', 1 ).
test( 't60', 725, [], [], 'fam1', 1 ).
test( 't61', 101, ['m7','m18','m21','m42','m23','m1','m20','m36','m16','m9','m34','m17','m28','m19','m12','m24','m41'], [], 'fam1', 1 ).
test( 't62', 516, [], [], 'fam1', 1 ).
test( 't63', 629, [], [], 'fam1', 1 ).
test( 't64', 118, [], [], 'fam1', 1 ).
test( 't65', 558, [], ['r5','r2','r1','r3'], 'fam1', 1 ).
test( 't66', 109, [], [], 'fam1', 1 ).
test( 't67', 515, [], ['r3','r1','r4','r5','r2'], 'fam1', 1 ).
test( 't68', 673, [], [], 'fam1', 1 ).
test( 't69', 179, ['m4','m42','m23','m10','m3','m36','m25','m39','m47','m19','m15','m16','m2','m26','m34','m12','m21','m5','m18'], ['r1','r4'], 'fam1', 1 ).
test( 't70', 768, [], ['r3','r5','r2'], 'fam1', 1 ).
test( 't71', 397, ['m14','m35','m39','m31','m9','m42','m45','m33','m24','m30','m23','m36','m34','m44','m22','m7','m11','m43'], ['r3','r5','r4','r1'], 'fam1', 1 ).
test( 't72', 766, ['m6'], ['r5','r2'], 'fam1', 1 ).
test( 't73', 430, ['m4','m8','m46','m29','m11','m2','m40','m23','m22','m19','m33','m15','m49','m36','m1','m21','m7','m25','m24','m39'], ['r3'], 'fam1', 1 ).
test( 't74', 237, [], [], 'fam1', 1 ).
test( 't75', 653, ['m26','m47','m17','m33','m8','m28','m2','m36','m37','m27','m39','m42','m43','m44','m48','m3','m9','m1','m7'], ['r1'], 'fam1', 1 ).
test( 't76', 709, [], [], 'fam1', 1 ).
test( 't77', 266, ['m9','m40','m10','m29','m50','m22','m19','m26'], ['r1','r3'], 'fam1', 1 ).
test( 't78', 719, [], ['r4','r2','r1'], 'fam1', 1 ).
test( 't79', 188, [], [], 'fam1', 1 ).
test( 't80', 122, ['m26','m35','m7','m49','m25','m16','m14'], [], 'fam1', 1 ).
test( 't81', 798, [], [], 'fam1', 1 ).
test( 't82', 399, [], [], 'fam1', 1 ).
test( 't83', 756, [], [], 'fam1', 1 ).
test( 't84', 142, [], [], 'fam1', 1 ).
test( 't85', 708, [], [], 'fam1', 1 ).
test( 't86', 770, ['m37','m28','m39','m23','m13','m25','m48','m31','m8'], [], 'fam1', 1 ).
test( 't87', 315, ['m30','m10','m25','m43'], [], 'fam1', 1 ).
test( 't88', 535, [], [], 'fam1', 1 ).
test( 't89', 375, [], [], 'fam1', 1 ).
test( 't90', 132, [], [], 'fam1', 1 ).
test( 't91', 617, [], [], 'fam1', 1 ).
test( 't92', 494, ['m13','m42','m14','m25','m20','m11','m29','m43'], [], 'fam1', 1 ).
test( 't93', 297, [], ['r5','r3','r1','r2'], 'fam1', 1 ).
test( 't94', 519, ['m36','m21','m12','m18','m42','m25','m16','m17','m23','m5','m6','m4','m2','m15','m47','m26'], [], 'fam1', 1 ).
test( 't95', 574, ['m13','m24','m12','m9','m29','m4','m43','m5','m40','m27','m38','m2','m31','m17','m39','m33','m15'], [], 'fam1', 1 ).
test( 't96', 34, [], ['r5','r2','r1','r4','r3'], 'fam1', 1 ).
test( 't97', 424, [], ['r1','r4','r3','r2','r5'], 'fam1', 1 ).
test( 't98', 510, [], [], 'fam1', 1 ).
test( 't99', 794, ['m9','m48','m40','m6','m1','m39','m5','m2','m20','m23','m13'], ['r1'], 'fam1', 1 ).
test( 't100', 8, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').
embedded_board( 'm21').
embedded_board( 'm22').
embedded_board( 'm23').
embedded_board( 'm24').
embedded_board( 'm25').
embedded_board( 'm26').
embedded_board( 'm27').
embedded_board( 'm28').
embedded_board( 'm29').
embedded_board( 'm30').
embedded_board( 'm31').
embedded_board( 'm32').
embedded_board( 'm33').
embedded_board( 'm34').
embedded_board( 'm35').
embedded_board( 'm36').
embedded_board( 'm37').
embedded_board( 'm38').
embedded_board( 'm39').
embedded_board( 'm40').
embedded_board( 'm41').
embedded_board( 'm42').
embedded_board( 'm43').
embedded_board( 'm44').
embedded_board( 'm45').
embedded_board( 'm46').
embedded_board( 'm47').
embedded_board( 'm48').
embedded_board( 'm49').
embedded_board( 'm50').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
