%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 25, [], ['r2','r3'], 'fam1', 1 ).
test( 't2', 223, [], [], 'fam1', 1 ).
test( 't3', 782, [], [], 'fam1', 1 ).
test( 't4', 720, [], [], 'fam1', 1 ).
test( 't5', 498, [], [], 'fam1', 1 ).
test( 't6', 656, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't7', 287, ['m15','m20','m9','m12','m6','m7','m11'], [], 'fam1', 1 ).
test( 't8', 448, [], [], 'fam1', 1 ).
test( 't9', 207, ['m3','m19','m12','m7','m18'], [], 'fam1', 1 ).
test( 't10', 561, [], [], 'fam1', 1 ).
test( 't11', 317, [], [], 'fam1', 1 ).
test( 't12', 43, [], ['r3'], 'fam1', 1 ).
test( 't13', 401, [], [], 'fam1', 1 ).
test( 't14', 189, [], [], 'fam1', 1 ).
test( 't15', 356, [], [], 'fam1', 1 ).
test( 't16', 25, [], [], 'fam1', 1 ).
test( 't17', 387, [], [], 'fam1', 1 ).
test( 't18', 352, [], [], 'fam1', 1 ).
test( 't19', 253, [], [], 'fam1', 1 ).
test( 't20', 23, [], ['r2'], 'fam1', 1 ).
test( 't21', 35, [], ['r3'], 'fam1', 1 ).
test( 't22', 521, ['m11','m12','m5','m6','m7','m20','m13'], ['r2','r1','r3'], 'fam1', 1 ).
test( 't23', 171, [], [], 'fam1', 1 ).
test( 't24', 771, [], [], 'fam1', 1 ).
test( 't25', 26, [], [], 'fam1', 1 ).
test( 't26', 146, [], [], 'fam1', 1 ).
test( 't27', 453, [], [], 'fam1', 1 ).
test( 't28', 177, [], [], 'fam1', 1 ).
test( 't29', 22, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't30', 721, [], [], 'fam1', 1 ).
test( 't31', 730, [], [], 'fam1', 1 ).
test( 't32', 542, ['m15','m19','m3','m5','m9','m11','m6','m14'], [], 'fam1', 1 ).
test( 't33', 556, [], [], 'fam1', 1 ).
test( 't34', 786, [], [], 'fam1', 1 ).
test( 't35', 548, ['m5'], ['r3','r1'], 'fam1', 1 ).
test( 't36', 155, [], [], 'fam1', 1 ).
test( 't37', 153, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't38', 528, [], [], 'fam1', 1 ).
test( 't39', 311, [], ['r1'], 'fam1', 1 ).
test( 't40', 697, [], [], 'fam1', 1 ).
test( 't41', 296, [], ['r1'], 'fam1', 1 ).
test( 't42', 353, [], [], 'fam1', 1 ).
test( 't43', 120, [], [], 'fam1', 1 ).
test( 't44', 31, [], [], 'fam1', 1 ).
test( 't45', 432, [], ['r3'], 'fam1', 1 ).
test( 't46', 79, [], [], 'fam1', 1 ).
test( 't47', 661, [], ['r1'], 'fam1', 1 ).
test( 't48', 322, [], [], 'fam1', 1 ).
test( 't49', 725, [], [], 'fam1', 1 ).
test( 't50', 206, [], [], 'fam1', 1 ).
test( 't51', 318, [], [], 'fam1', 1 ).
test( 't52', 138, ['m13','m14','m18'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't53', 572, [], [], 'fam1', 1 ).
test( 't54', 109, [], [], 'fam1', 1 ).
test( 't55', 179, [], [], 'fam1', 1 ).
test( 't56', 178, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't57', 789, [], [], 'fam1', 1 ).
test( 't58', 130, [], [], 'fam1', 1 ).
test( 't59', 555, [], [], 'fam1', 1 ).
test( 't60', 493, ['m5','m7','m16'], [], 'fam1', 1 ).
test( 't61', 763, ['m16','m3','m8','m20','m1','m15','m7','m10'], ['r3','r2'], 'fam1', 1 ).
test( 't62', 74, ['m14','m5','m3'], ['r1'], 'fam1', 1 ).
test( 't63', 530, [], [], 'fam1', 1 ).
test( 't64', 239, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't65', 560, ['m16','m5','m12','m6','m1','m13','m17'], [], 'fam1', 1 ).
test( 't66', 268, ['m5','m2','m8','m16','m11','m10','m9'], [], 'fam1', 1 ).
test( 't67', 754, [], [], 'fam1', 1 ).
test( 't68', 563, [], [], 'fam1', 1 ).
test( 't69', 589, [], [], 'fam1', 1 ).
test( 't70', 434, [], [], 'fam1', 1 ).
test( 't71', 350, [], [], 'fam1', 1 ).
test( 't72', 115, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't73', 420, [], [], 'fam1', 1 ).
test( 't74', 438, ['m7','m20'], ['r2','r3'], 'fam1', 1 ).
test( 't75', 457, [], ['r1','r3'], 'fam1', 1 ).
test( 't76', 89, [], [], 'fam1', 1 ).
test( 't77', 225, [], ['r2'], 'fam1', 1 ).
test( 't78', 320, ['m9','m17','m12','m15'], [], 'fam1', 1 ).
test( 't79', 438, [], [], 'fam1', 1 ).
test( 't80', 669, [], [], 'fam1', 1 ).
test( 't81', 654, ['m2'], [], 'fam1', 1 ).
test( 't82', 737, [], [], 'fam1', 1 ).
test( 't83', 345, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't84', 552, [], [], 'fam1', 1 ).
test( 't85', 697, [], ['r3','r1'], 'fam1', 1 ).
test( 't86', 531, [], [], 'fam1', 1 ).
test( 't87', 217, ['m14','m1','m2','m8','m19','m10','m12','m13'], [], 'fam1', 1 ).
test( 't88', 620, [], ['r2','r3'], 'fam1', 1 ).
test( 't89', 671, [], [], 'fam1', 1 ).
test( 't90', 538, [], [], 'fam1', 1 ).
test( 't91', 160, [], ['r2','r3'], 'fam1', 1 ).
test( 't92', 755, [], [], 'fam1', 1 ).
test( 't93', 439, [], ['r2','r1'], 'fam1', 1 ).
test( 't94', 54, [], [], 'fam1', 1 ).
test( 't95', 115, ['m17','m2','m8','m3','m9','m18'], [], 'fam1', 1 ).
test( 't96', 578, ['m18','m5','m8','m4','m10','m17','m13','m9'], [], 'fam1', 1 ).
test( 't97', 772, [], [], 'fam1', 1 ).
test( 't98', 47, [], [], 'fam1', 1 ).
test( 't99', 759, [], [], 'fam1', 1 ).
test( 't100', 782, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
