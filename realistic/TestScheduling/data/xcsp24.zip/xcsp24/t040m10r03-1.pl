%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 160, [], [], 'fam1', 1 ).
test( 't2', 639, [], [], 'fam1', 1 ).
test( 't3', 205, [], [], 'fam1', 1 ).
test( 't4', 163, [], ['r2','r1'], 'fam1', 1 ).
test( 't5', 801, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't6', 78, [], [], 'fam1', 1 ).
test( 't7', 528, [], ['r2','r3','r1'], 'fam1', 1 ).
test( 't8', 458, ['m2','m6','m7','m9'], [], 'fam1', 1 ).
test( 't9', 272, [], [], 'fam1', 1 ).
test( 't10', 236, [], [], 'fam1', 1 ).
test( 't11', 470, [], [], 'fam1', 1 ).
test( 't12', 679, [], [], 'fam1', 1 ).
test( 't13', 178, [], [], 'fam1', 1 ).
test( 't14', 291, [], [], 'fam1', 1 ).
test( 't15', 712, [], ['r3','r1'], 'fam1', 1 ).
test( 't16', 274, ['m1','m2','m5'], [], 'fam1', 1 ).
test( 't17', 7, ['m8','m2','m5','m3'], [], 'fam1', 1 ).
test( 't18', 245, ['m8'], [], 'fam1', 1 ).
test( 't19', 747, [], [], 'fam1', 1 ).
test( 't20', 364, ['m10','m7'], [], 'fam1', 1 ).
test( 't21', 511, ['m5','m3','m6'], [], 'fam1', 1 ).
test( 't22', 291, [], ['r3','r1','r2'], 'fam1', 1 ).
test( 't23', 341, [], [], 'fam1', 1 ).
test( 't24', 364, [], [], 'fam1', 1 ).
test( 't25', 221, ['m1','m3','m6'], [], 'fam1', 1 ).
test( 't26', 752, [], [], 'fam1', 1 ).
test( 't27', 16, ['m7','m5','m3'], ['r1','r2'], 'fam1', 1 ).
test( 't28', 223, [], [], 'fam1', 1 ).
test( 't29', 88, [], [], 'fam1', 1 ).
test( 't30', 215, ['m10'], [], 'fam1', 1 ).
test( 't31', 792, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't32', 528, [], [], 'fam1', 1 ).
test( 't33', 629, [], ['r2','r1'], 'fam1', 1 ).
test( 't34', 528, [], [], 'fam1', 1 ).
test( 't35', 34, [], [], 'fam1', 1 ).
test( 't36', 785, [], ['r1'], 'fam1', 1 ).
test( 't37', 119, [], [], 'fam1', 1 ).
test( 't38', 576, [], [], 'fam1', 1 ).
test( 't39', 115, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't40', 179, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
