%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 346, [], ['r1','r3','r5','r2','r4'], 'fam1', 1 ).
test( 't2', 439, ['m6','m5','m8'], [], 'fam1', 1 ).
test( 't3', 120, [], [], 'fam1', 1 ).
test( 't4', 150, [], [], 'fam1', 1 ).
test( 't5', 718, [], [], 'fam1', 1 ).
test( 't6', 326, [], [], 'fam1', 1 ).
test( 't7', 265, [], [], 'fam1', 1 ).
test( 't8', 782, ['m5','m2','m7','m8'], [], 'fam1', 1 ).
test( 't9', 170, [], ['r3','r4','r2','r5'], 'fam1', 1 ).
test( 't10', 789, [], [], 'fam1', 1 ).
test( 't11', 59, ['m4','m5','m7','m10'], [], 'fam1', 1 ).
test( 't12', 126, [], [], 'fam1', 1 ).
test( 't13', 481, [], ['r2'], 'fam1', 1 ).
test( 't14', 761, [], [], 'fam1', 1 ).
test( 't15', 324, ['m2','m7'], [], 'fam1', 1 ).
test( 't16', 243, [], [], 'fam1', 1 ).
test( 't17', 12, [], [], 'fam1', 1 ).
test( 't18', 373, ['m9'], [], 'fam1', 1 ).
test( 't19', 720, [], [], 'fam1', 1 ).
test( 't20', 597, [], ['r5','r4','r3','r1','r2'], 'fam1', 1 ).
test( 't21', 133, ['m6','m9','m1'], [], 'fam1', 1 ).
test( 't22', 404, ['m8','m4','m5'], ['r2','r4','r5'], 'fam1', 1 ).
test( 't23', 471, ['m2'], [], 'fam1', 1 ).
test( 't24', 629, [], [], 'fam1', 1 ).
test( 't25', 181, [], ['r4','r3','r5','r1'], 'fam1', 1 ).
test( 't26', 275, [], [], 'fam1', 1 ).
test( 't27', 219, [], [], 'fam1', 1 ).
test( 't28', 222, ['m2','m4','m9'], [], 'fam1', 1 ).
test( 't29', 62, [], [], 'fam1', 1 ).
test( 't30', 473, ['m4','m3'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
