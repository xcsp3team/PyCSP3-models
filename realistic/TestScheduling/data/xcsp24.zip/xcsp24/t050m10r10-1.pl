%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 274, ['m6','m4','m5'], [], 'fam1', 1 ).
test( 't2', 653, [], [], 'fam1', 1 ).
test( 't3', 661, ['m2'], [], 'fam1', 1 ).
test( 't4', 596, [], [], 'fam1', 1 ).
test( 't5', 420, [], ['r3','r6','r7'], 'fam1', 1 ).
test( 't6', 185, ['m2','m4','m10','m7'], [], 'fam1', 1 ).
test( 't7', 763, [], [], 'fam1', 1 ).
test( 't8', 431, [], ['r9','r7','r3','r2','r10','r4','r1','r6','r5','r8'], 'fam1', 1 ).
test( 't9', 466, [], [], 'fam1', 1 ).
test( 't10', 31, [], [], 'fam1', 1 ).
test( 't11', 517, [], ['r8','r6','r3','r2','r1','r5','r7','r10'], 'fam1', 1 ).
test( 't12', 316, [], [], 'fam1', 1 ).
test( 't13', 397, [], [], 'fam1', 1 ).
test( 't14', 611, [], [], 'fam1', 1 ).
test( 't15', 336, ['m6','m5','m7','m1'], [], 'fam1', 1 ).
test( 't16', 678, [], [], 'fam1', 1 ).
test( 't17', 762, ['m6','m9','m7'], [], 'fam1', 1 ).
test( 't18', 741, [], [], 'fam1', 1 ).
test( 't19', 594, [], ['r9','r4','r8','r3','r7','r5','r10'], 'fam1', 1 ).
test( 't20', 535, ['m8','m9','m7','m6'], ['r1','r8'], 'fam1', 1 ).
test( 't21', 594, [], ['r10','r8','r5','r1','r7','r3','r6','r9','r4','r2'], 'fam1', 1 ).
test( 't22', 37, [], ['r10','r6','r5','r7','r8','r3','r1','r4'], 'fam1', 1 ).
test( 't23', 402, [], [], 'fam1', 1 ).
test( 't24', 543, [], [], 'fam1', 1 ).
test( 't25', 617, [], [], 'fam1', 1 ).
test( 't26', 786, ['m7','m8','m5','m6'], [], 'fam1', 1 ).
test( 't27', 391, [], [], 'fam1', 1 ).
test( 't28', 556, ['m4','m10','m6'], ['r4','r7','r8','r9','r5','r6','r3'], 'fam1', 1 ).
test( 't29', 500, [], [], 'fam1', 1 ).
test( 't30', 163, ['m8','m7','m10','m2'], [], 'fam1', 1 ).
test( 't31', 605, [], [], 'fam1', 1 ).
test( 't32', 343, [], [], 'fam1', 1 ).
test( 't33', 701, ['m3','m9'], ['r7','r2','r10','r3','r8','r5','r4','r9','r6','r1'], 'fam1', 1 ).
test( 't34', 659, [], ['r5','r6'], 'fam1', 1 ).
test( 't35', 645, ['m1','m10'], [], 'fam1', 1 ).
test( 't36', 228, ['m9','m5','m7'], [], 'fam1', 1 ).
test( 't37', 405, [], ['r3','r9','r5','r2','r6'], 'fam1', 1 ).
test( 't38', 308, [], ['r8'], 'fam1', 1 ).
test( 't39', 457, [], [], 'fam1', 1 ).
test( 't40', 459, ['m5','m2'], [], 'fam1', 1 ).
test( 't41', 441, [], [], 'fam1', 1 ).
test( 't42', 544, [], [], 'fam1', 1 ).
test( 't43', 453, [], [], 'fam1', 1 ).
test( 't44', 328, [], ['r9','r6','r3','r7','r8'], 'fam1', 1 ).
test( 't45', 296, ['m7','m3'], [], 'fam1', 1 ).
test( 't46', 322, [], [], 'fam1', 1 ).
test( 't47', 729, [], ['r3','r5','r10','r9'], 'fam1', 1 ).
test( 't48', 441, [], [], 'fam1', 1 ).
test( 't49', 528, ['m6','m1','m9'], ['r10','r8','r2','r4','r9','r3','r7','r5','r1'], 'fam1', 1 ).
test( 't50', 27, ['m10'], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
