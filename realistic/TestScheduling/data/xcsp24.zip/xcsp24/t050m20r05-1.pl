%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 612, [], [], 'fam1', 1 ).
test( 't2', 467, ['m12'], [], 'fam1', 1 ).
test( 't3', 237, ['m18','m3','m2','m20','m6','m19','m9'], [], 'fam1', 1 ).
test( 't4', 264, [], [], 'fam1', 1 ).
test( 't5', 39, [], [], 'fam1', 1 ).
test( 't6', 75, [], [], 'fam1', 1 ).
test( 't7', 535, [], [], 'fam1', 1 ).
test( 't8', 438, [], [], 'fam1', 1 ).
test( 't9', 103, [], ['r5','r3','r4','r2','r1'], 'fam1', 1 ).
test( 't10', 413, [], [], 'fam1', 1 ).
test( 't11', 14, [], ['r3','r4','r2','r1'], 'fam1', 1 ).
test( 't12', 317, [], [], 'fam1', 1 ).
test( 't13', 170, ['m2'], ['r4','r1','r3','r5','r2'], 'fam1', 1 ).
test( 't14', 543, ['m13','m3','m15','m20','m10','m17'], [], 'fam1', 1 ).
test( 't15', 89, ['m18','m1','m12','m11','m3','m5','m7','m6'], [], 'fam1', 1 ).
test( 't16', 499, ['m6','m13','m15','m19','m12'], ['r4','r5'], 'fam1', 1 ).
test( 't17', 592, [], [], 'fam1', 1 ).
test( 't18', 36, [], [], 'fam1', 1 ).
test( 't19', 352, [], [], 'fam1', 1 ).
test( 't20', 519, [], ['r5','r1','r2'], 'fam1', 1 ).
test( 't21', 289, ['m3','m8','m4','m17','m6','m15'], ['r3','r4','r2','r5'], 'fam1', 1 ).
test( 't22', 564, [], ['r5','r3'], 'fam1', 1 ).
test( 't23', 375, ['m14','m7','m8','m13','m19','m16','m20','m18'], [], 'fam1', 1 ).
test( 't24', 236, ['m18','m12','m9','m13','m1'], [], 'fam1', 1 ).
test( 't25', 595, [], [], 'fam1', 1 ).
test( 't26', 195, [], [], 'fam1', 1 ).
test( 't27', 578, [], [], 'fam1', 1 ).
test( 't28', 753, [], [], 'fam1', 1 ).
test( 't29', 483, [], [], 'fam1', 1 ).
test( 't30', 45, [], [], 'fam1', 1 ).
test( 't31', 268, [], [], 'fam1', 1 ).
test( 't32', 610, [], ['r3','r2','r1'], 'fam1', 1 ).
test( 't33', 627, [], [], 'fam1', 1 ).
test( 't34', 772, ['m12','m7','m2','m1','m10','m14','m8'], ['r1','r2','r3','r4','r5'], 'fam1', 1 ).
test( 't35', 91, [], ['r5','r3','r4','r2','r1'], 'fam1', 1 ).
test( 't36', 694, [], [], 'fam1', 1 ).
test( 't37', 59, [], ['r3','r1','r5','r2'], 'fam1', 1 ).
test( 't38', 166, [], ['r5','r4','r1'], 'fam1', 1 ).
test( 't39', 450, [], ['r2','r1','r5'], 'fam1', 1 ).
test( 't40', 585, [], [], 'fam1', 1 ).
test( 't41', 42, [], [], 'fam1', 1 ).
test( 't42', 642, ['m8','m10','m2','m15','m5','m13','m9','m17'], ['r1','r3','r4','r2'], 'fam1', 1 ).
test( 't43', 658, [], [], 'fam1', 1 ).
test( 't44', 323, [], [], 'fam1', 1 ).
test( 't45', 644, [], ['r3','r4','r1','r5'], 'fam1', 1 ).
test( 't46', 55, [], [], 'fam1', 1 ).
test( 't47', 662, [], ['r3','r2'], 'fam1', 1 ).
test( 't48', 304, [], [], 'fam1', 1 ).
test( 't49', 684, [], ['r3','r5'], 'fam1', 1 ).
test( 't50', 389, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
