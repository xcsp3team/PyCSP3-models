%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 371, [], [], 'fam1', 1 ).
test( 't2', 141, [], [], 'fam1', 1 ).
test( 't3', 122, [], [], 'fam1', 1 ).
test( 't4', 642, [], [], 'fam1', 1 ).
test( 't5', 376, [], [], 'fam1', 1 ).
test( 't6', 631, ['m10'], [], 'fam1', 1 ).
test( 't7', 147, [], [], 'fam1', 1 ).
test( 't8', 764, ['m8'], [], 'fam1', 1 ).
test( 't9', 462, [], [], 'fam1', 1 ).
test( 't10', 558, [], ['r1','r3','r4','r2'], 'fam1', 1 ).
test( 't11', 512, [], [], 'fam1', 1 ).
test( 't12', 703, [], ['r2','r1'], 'fam1', 1 ).
test( 't13', 371, [], [], 'fam1', 1 ).
test( 't14', 57, [], [], 'fam1', 1 ).
test( 't15', 738, ['m6','m7','m8'], [], 'fam1', 1 ).
test( 't16', 184, [], [], 'fam1', 1 ).
test( 't17', 610, [], [], 'fam1', 1 ).
test( 't18', 626, [], ['r3','r5','r4','r2'], 'fam1', 1 ).
test( 't19', 621, [], [], 'fam1', 1 ).
test( 't20', 676, ['m6','m2'], [], 'fam1', 1 ).
test( 't21', 450, [], ['r2','r1','r4','r3'], 'fam1', 1 ).
test( 't22', 276, [], ['r1','r4'], 'fam1', 1 ).
test( 't23', 61, [], [], 'fam1', 1 ).
test( 't24', 122, [], [], 'fam1', 1 ).
test( 't25', 433, ['m5','m1'], ['r4','r3','r2'], 'fam1', 1 ).
test( 't26', 96, [], ['r3','r5','r2','r1'], 'fam1', 1 ).
test( 't27', 327, [], [], 'fam1', 1 ).
test( 't28', 30, [], [], 'fam1', 1 ).
test( 't29', 505, [], ['r2','r4','r3','r1','r5'], 'fam1', 1 ).
test( 't30', 608, [], ['r2','r5'], 'fam1', 1 ).
test( 't31', 309, [], ['r1','r2','r5','r3'], 'fam1', 1 ).
test( 't32', 786, ['m3'], [], 'fam1', 1 ).
test( 't33', 121, [], [], 'fam1', 1 ).
test( 't34', 34, ['m1','m10','m2','m5'], [], 'fam1', 1 ).
test( 't35', 215, ['m4','m8','m10','m9'], [], 'fam1', 1 ).
test( 't36', 567, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't37', 402, [], [], 'fam1', 1 ).
test( 't38', 201, [], [], 'fam1', 1 ).
test( 't39', 315, [], [], 'fam1', 1 ).
test( 't40', 511, [], [], 'fam1', 1 ).
test( 't41', 662, [], [], 'fam1', 1 ).
test( 't42', 308, ['m6','m4','m8','m1'], [], 'fam1', 1 ).
test( 't43', 755, [], [], 'fam1', 1 ).
test( 't44', 299, ['m6','m10'], [], 'fam1', 1 ).
test( 't45', 433, ['m5','m3'], [], 'fam1', 1 ).
test( 't46', 723, ['m10','m3'], [], 'fam1', 1 ).
test( 't47', 542, [], ['r1','r3','r4','r2'], 'fam1', 1 ).
test( 't48', 251, [], [], 'fam1', 1 ).
test( 't49', 466, [], ['r5','r3','r4'], 'fam1', 1 ).
test( 't50', 67, [], ['r4','r1'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
