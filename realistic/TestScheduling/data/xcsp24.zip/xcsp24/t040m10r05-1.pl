%% ****  Testsuite  ****
% Number of tests                  : 40
% Number of machines               : 10
% Number of resources              : 5
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 358, [], [], 'fam1', 1 ).
test( 't2', 302, [], [], 'fam1', 1 ).
test( 't3', 717, ['m5','m10'], [], 'fam1', 1 ).
test( 't4', 554, ['m6'], [], 'fam1', 1 ).
test( 't5', 378, [], [], 'fam1', 1 ).
test( 't6', 202, [], [], 'fam1', 1 ).
test( 't7', 509, [], [], 'fam1', 1 ).
test( 't8', 748, [], ['r3'], 'fam1', 1 ).
test( 't9', 397, [], ['r4','r2','r5','r3'], 'fam1', 1 ).
test( 't10', 123, [], [], 'fam1', 1 ).
test( 't11', 488, [], ['r2','r1','r3'], 'fam1', 1 ).
test( 't12', 356, [], ['r2'], 'fam1', 1 ).
test( 't13', 15, ['m3','m9','m4'], ['r5','r1','r2'], 'fam1', 1 ).
test( 't14', 788, [], [], 'fam1', 1 ).
test( 't15', 604, [], [], 'fam1', 1 ).
test( 't16', 593, ['m10'], [], 'fam1', 1 ).
test( 't17', 331, [], [], 'fam1', 1 ).
test( 't18', 14, [], [], 'fam1', 1 ).
test( 't19', 286, [], [], 'fam1', 1 ).
test( 't20', 338, [], [], 'fam1', 1 ).
test( 't21', 698, ['m3'], [], 'fam1', 1 ).
test( 't22', 121, [], ['r1'], 'fam1', 1 ).
test( 't23', 1, ['m2','m5','m6'], ['r3','r2','r4'], 'fam1', 1 ).
test( 't24', 536, ['m4','m10','m6'], [], 'fam1', 1 ).
test( 't25', 263, ['m3','m5','m4','m10'], ['r3','r2','r1'], 'fam1', 1 ).
test( 't26', 254, [], ['r2','r5','r3','r1','r4'], 'fam1', 1 ).
test( 't27', 106, ['m1','m2','m4'], ['r5','r4','r2','r1','r3'], 'fam1', 1 ).
test( 't28', 214, ['m9'], [], 'fam1', 1 ).
test( 't29', 691, [], ['r2','r3','r1','r4'], 'fam1', 1 ).
test( 't30', 660, ['m5','m9','m2'], [], 'fam1', 1 ).
test( 't31', 618, [], [], 'fam1', 1 ).
test( 't32', 322, [], [], 'fam1', 1 ).
test( 't33', 484, [], [], 'fam1', 1 ).
test( 't34', 7, [], ['r3','r5'], 'fam1', 1 ).
test( 't35', 695, [], ['r3','r5','r2'], 'fam1', 1 ).
test( 't36', 133, [], [], 'fam1', 1 ).
test( 't37', 251, [], [], 'fam1', 1 ).
test( 't38', 624, [], [], 'fam1', 1 ).
test( 't39', 587, [], ['r3'], 'fam1', 1 ).
test( 't40', 620, [], ['r4','r1','r3','r2','r5'], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
