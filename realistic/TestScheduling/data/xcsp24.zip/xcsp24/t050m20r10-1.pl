%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 524, ['m6','m15','m7'], [], 'fam1', 1 ).
test( 't2', 742, ['m20','m2','m1','m11','m19','m13','m6','m7'], [], 'fam1', 1 ).
test( 't3', 353, ['m9','m3'], [], 'fam1', 1 ).
test( 't4', 254, [], ['r10','r1','r5'], 'fam1', 1 ).
test( 't5', 412, [], [], 'fam1', 1 ).
test( 't6', 760, [], ['r6','r8','r7','r3','r2','r1','r5','r10','r9'], 'fam1', 1 ).
test( 't7', 193, [], [], 'fam1', 1 ).
test( 't8', 212, [], ['r4','r3','r10','r8','r9','r2'], 'fam1', 1 ).
test( 't9', 465, [], [], 'fam1', 1 ).
test( 't10', 311, [], ['r6','r10','r7','r5','r8','r1'], 'fam1', 1 ).
test( 't11', 354, ['m7','m3','m1','m5'], [], 'fam1', 1 ).
test( 't12', 10, [], [], 'fam1', 1 ).
test( 't13', 450, ['m18','m3','m9','m6'], [], 'fam1', 1 ).
test( 't14', 418, [], ['r7','r5','r10','r9','r1','r2'], 'fam1', 1 ).
test( 't15', 267, [], [], 'fam1', 1 ).
test( 't16', 444, [], ['r8','r6','r10','r1','r4','r3','r2','r9'], 'fam1', 1 ).
test( 't17', 588, [], ['r3','r1','r8','r7','r10','r9','r4','r2','r5','r6'], 'fam1', 1 ).
test( 't18', 775, ['m10'], [], 'fam1', 1 ).
test( 't19', 480, ['m11','m12','m17','m2','m9','m19'], [], 'fam1', 1 ).
test( 't20', 87, [], [], 'fam1', 1 ).
test( 't21', 522, [], [], 'fam1', 1 ).
test( 't22', 289, [], [], 'fam1', 1 ).
test( 't23', 260, [], ['r7'], 'fam1', 1 ).
test( 't24', 396, [], ['r8','r6','r10'], 'fam1', 1 ).
test( 't25', 286, [], [], 'fam1', 1 ).
test( 't26', 800, ['m16','m14'], [], 'fam1', 1 ).
test( 't27', 219, ['m14','m5'], [], 'fam1', 1 ).
test( 't28', 721, [], [], 'fam1', 1 ).
test( 't29', 710, [], [], 'fam1', 1 ).
test( 't30', 72, [], ['r10','r6','r3'], 'fam1', 1 ).
test( 't31', 707, [], [], 'fam1', 1 ).
test( 't32', 484, [], [], 'fam1', 1 ).
test( 't33', 421, [], ['r10','r3','r9','r7','r5','r4'], 'fam1', 1 ).
test( 't34', 156, [], [], 'fam1', 1 ).
test( 't35', 40, ['m6','m18','m9','m1','m11','m14','m16'], [], 'fam1', 1 ).
test( 't36', 693, [], [], 'fam1', 1 ).
test( 't37', 529, [], [], 'fam1', 1 ).
test( 't38', 432, [], [], 'fam1', 1 ).
test( 't39', 678, [], [], 'fam1', 1 ).
test( 't40', 77, ['m14','m7','m3','m5','m13','m9'], ['r3','r2','r9','r4','r8','r1'], 'fam1', 1 ).
test( 't41', 677, [], ['r3','r5','r2','r6','r4','r9'], 'fam1', 1 ).
test( 't42', 250, [], [], 'fam1', 1 ).
test( 't43', 465, [], [], 'fam1', 1 ).
test( 't44', 148, [], ['r5'], 'fam1', 1 ).
test( 't45', 702, ['m3','m13','m12','m17','m8','m1','m7','m20'], [], 'fam1', 1 ).
test( 't46', 617, [], [], 'fam1', 1 ).
test( 't47', 581, [], ['r9','r4','r5','r3','r6','r1','r8','r7','r10'], 'fam1', 1 ).
test( 't48', 261, ['m5','m8','m3'], [], 'fam1', 1 ).
test( 't49', 399, [], [], 'fam1', 1 ).
test( 't50', 601, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
