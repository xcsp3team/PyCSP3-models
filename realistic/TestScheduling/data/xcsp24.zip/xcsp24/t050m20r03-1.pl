%% ****  Testsuite  ****
% Number of tests                  : 50
% Number of machines               : 20
% Number of resources              : 3
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 303, ['m3','m11','m4'], [], 'fam1', 1 ).
test( 't2', 466, [], [], 'fam1', 1 ).
test( 't3', 43, [], [], 'fam1', 1 ).
test( 't4', 786, [], [], 'fam1', 1 ).
test( 't5', 309, [], ['r2','r3'], 'fam1', 1 ).
test( 't6', 55, ['m13','m4','m8','m1','m2','m11'], [], 'fam1', 1 ).
test( 't7', 407, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't8', 128, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't9', 575, [], [], 'fam1', 1 ).
test( 't10', 739, ['m11'], [], 'fam1', 1 ).
test( 't11', 38, [], [], 'fam1', 1 ).
test( 't12', 681, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't13', 739, [], [], 'fam1', 1 ).
test( 't14', 587, [], [], 'fam1', 1 ).
test( 't15', 163, [], [], 'fam1', 1 ).
test( 't16', 593, [], ['r1','r3'], 'fam1', 1 ).
test( 't17', 589, [], [], 'fam1', 1 ).
test( 't18', 493, [], ['r3','r2'], 'fam1', 1 ).
test( 't19', 688, [], [], 'fam1', 1 ).
test( 't20', 652, [], [], 'fam1', 1 ).
test( 't21', 78, [], [], 'fam1', 1 ).
test( 't22', 785, [], [], 'fam1', 1 ).
test( 't23', 136, [], [], 'fam1', 1 ).
test( 't24', 206, [], [], 'fam1', 1 ).
test( 't25', 136, [], [], 'fam1', 1 ).
test( 't26', 138, [], [], 'fam1', 1 ).
test( 't27', 566, [], [], 'fam1', 1 ).
test( 't28', 676, ['m17','m18','m10','m20','m11','m12'], [], 'fam1', 1 ).
test( 't29', 259, [], ['r1','r3','r2'], 'fam1', 1 ).
test( 't30', 693, ['m20'], ['r1','r3','r2'], 'fam1', 1 ).
test( 't31', 705, [], [], 'fam1', 1 ).
test( 't32', 27, [], ['r1','r2','r3'], 'fam1', 1 ).
test( 't33', 347, [], [], 'fam1', 1 ).
test( 't34', 345, [], [], 'fam1', 1 ).
test( 't35', 280, [], [], 'fam1', 1 ).
test( 't36', 540, ['m3','m14','m7','m8','m18','m13','m4'], [], 'fam1', 1 ).
test( 't37', 25, ['m4','m1','m15','m7','m12'], ['r2'], 'fam1', 1 ).
test( 't38', 786, [], [], 'fam1', 1 ).
test( 't39', 600, [], [], 'fam1', 1 ).
test( 't40', 62, [], [], 'fam1', 1 ).
test( 't41', 491, ['m12','m10'], [], 'fam1', 1 ).
test( 't42', 732, [], [], 'fam1', 1 ).
test( 't43', 456, [], [], 'fam1', 1 ).
test( 't44', 110, ['m6','m19','m9'], ['r3','r1'], 'fam1', 1 ).
test( 't45', 419, [], [], 'fam1', 1 ).
test( 't46', 169, [], ['r1','r3'], 'fam1', 1 ).
test( 't47', 37, [], [], 'fam1', 1 ).
test( 't48', 562, [], [], 'fam1', 1 ).
test( 't49', 262, ['m6','m18','m9','m20','m15'], [], 'fam1', 1 ).
test( 't50', 269, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
