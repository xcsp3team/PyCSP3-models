%% ****  Testsuite  ****
% Number of tests                  : 20
% Number of machines               : 10
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 657, [], [], 'fam1', 1 ).
test( 't2', 255, [], [], 'fam1', 1 ).
test( 't3', 651, ['m7'], [], 'fam1', 1 ).
test( 't4', 773, [], [], 'fam1', 1 ).
test( 't5', 382, [], [], 'fam1', 1 ).
test( 't6', 479, [], [], 'fam1', 1 ).
test( 't7', 304, [], [], 'fam1', 1 ).
test( 't8', 399, [], ['r4','r2','r3','r9'], 'fam1', 1 ).
test( 't9', 791, ['m9','m10','m4'], [], 'fam1', 1 ).
test( 't10', 574, [], [], 'fam1', 1 ).
test( 't11', 771, ['m10','m8'], ['r5','r8'], 'fam1', 1 ).
test( 't12', 401, [], [], 'fam1', 1 ).
test( 't13', 290, [], [], 'fam1', 1 ).
test( 't14', 158, ['m6'], ['r1'], 'fam1', 1 ).
test( 't15', 165, [], [], 'fam1', 1 ).
test( 't16', 604, [], [], 'fam1', 1 ).
test( 't17', 566, [], ['r8','r7','r3','r1','r2','r10','r6'], 'fam1', 1 ).
test( 't18', 139, [], ['r1'], 'fam1', 1 ).
test( 't19', 364, ['m8'], [], 'fam1', 1 ).
test( 't20', 461, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
