%% ****  Testsuite  ****
% Number of tests                  : 30
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 152, [], ['r10','r7','r6'], 'fam1', 1 ).
test( 't2', 431, [], ['r1','r7','r5','r4','r10','r2','r6','r3','r8','r9'], 'fam1', 1 ).
test( 't3', 482, [], [], 'fam1', 1 ).
test( 't4', 392, [], [], 'fam1', 1 ).
test( 't5', 476, [], [], 'fam1', 1 ).
test( 't6', 778, [], [], 'fam1', 1 ).
test( 't7', 664, [], ['r2','r6','r3','r8','r4','r1'], 'fam1', 1 ).
test( 't8', 25, [], ['r1','r7','r4'], 'fam1', 1 ).
test( 't9', 335, [], [], 'fam1', 1 ).
test( 't10', 14, [], [], 'fam1', 1 ).
test( 't11', 788, [], ['r7','r4','r6','r2','r1'], 'fam1', 1 ).
test( 't12', 520, ['m8','m17','m12','m6','m2','m16','m19','m3'], ['r3','r8','r7'], 'fam1', 1 ).
test( 't13', 228, [], [], 'fam1', 1 ).
test( 't14', 558, [], ['r2','r7','r3','r1','r8','r6'], 'fam1', 1 ).
test( 't15', 23, ['m8','m12','m2'], [], 'fam1', 1 ).
test( 't16', 290, [], [], 'fam1', 1 ).
test( 't17', 13, [], ['r3','r2','r4','r10'], 'fam1', 1 ).
test( 't18', 503, [], [], 'fam1', 1 ).
test( 't19', 202, [], ['r5','r10','r1','r4','r8','r3','r6','r2','r9'], 'fam1', 1 ).
test( 't20', 55, [], ['r3','r2','r6'], 'fam1', 1 ).
test( 't21', 350, [], [], 'fam1', 1 ).
test( 't22', 765, [], [], 'fam1', 1 ).
test( 't23', 253, ['m16','m7'], ['r9','r8','r5','r10','r7'], 'fam1', 1 ).
test( 't24', 257, ['m13'], [], 'fam1', 1 ).
test( 't25', 302, [], [], 'fam1', 1 ).
test( 't26', 410, [], [], 'fam1', 1 ).
test( 't27', 623, [], [], 'fam1', 1 ).
test( 't28', 96, [], ['r3','r4','r2','r1','r9','r7','r5'], 'fam1', 1 ).
test( 't29', 558, [], [], 'fam1', 1 ).
test( 't30', 660, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
