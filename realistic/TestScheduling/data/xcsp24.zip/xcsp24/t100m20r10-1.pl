%% ****  Testsuite  ****
% Number of tests                  : 100
% Number of machines               : 20
% Number of resources              : 10
% Number of families               : 1
% Prob that a test use a resource  : 30%
% Minimum test duration            : 1
% Maximim test duration            : 800
% MPri                             : 40%

test( 't1', 261, [], ['r8','r3','r1','r2','r6','r5','r4','r9'], 'fam1', 1 ).
test( 't2', 427, [], ['r4','r9','r7'], 'fam1', 1 ).
test( 't3', 544, [], [], 'fam1', 1 ).
test( 't4', 105, [], [], 'fam1', 1 ).
test( 't5', 114, [], [], 'fam1', 1 ).
test( 't6', 777, ['m2','m1','m14','m16','m18'], ['r8'], 'fam1', 1 ).
test( 't7', 320, [], [], 'fam1', 1 ).
test( 't8', 35, [], [], 'fam1', 1 ).
test( 't9', 314, [], [], 'fam1', 1 ).
test( 't10', 409, [], ['r9','r3','r10','r4','r1','r6','r5','r8','r7'], 'fam1', 1 ).
test( 't11', 569, [], ['r10','r9','r8','r5','r6','r4','r2','r7'], 'fam1', 1 ).
test( 't12', 22, [], [], 'fam1', 1 ).
test( 't13', 784, [], ['r3','r9','r2','r7','r6','r4','r5','r10','r1','r8'], 'fam1', 1 ).
test( 't14', 314, [], [], 'fam1', 1 ).
test( 't15', 800, [], [], 'fam1', 1 ).
test( 't16', 18, [], ['r4','r10','r3','r2','r9'], 'fam1', 1 ).
test( 't17', 58, ['m11','m9','m7','m20','m18','m19','m1','m2'], ['r2','r7','r1','r9','r5','r8'], 'fam1', 1 ).
test( 't18', 322, [], [], 'fam1', 1 ).
test( 't19', 542, [], [], 'fam1', 1 ).
test( 't20', 225, [], [], 'fam1', 1 ).
test( 't21', 752, [], [], 'fam1', 1 ).
test( 't22', 576, [], ['r4','r2','r9','r8','r3','r7','r10'], 'fam1', 1 ).
test( 't23', 146, ['m2'], [], 'fam1', 1 ).
test( 't24', 73, [], [], 'fam1', 1 ).
test( 't25', 285, [], [], 'fam1', 1 ).
test( 't26', 589, ['m11'], [], 'fam1', 1 ).
test( 't27', 331, [], [], 'fam1', 1 ).
test( 't28', 738, ['m1','m3'], [], 'fam1', 1 ).
test( 't29', 505, [], [], 'fam1', 1 ).
test( 't30', 423, [], ['r8','r5','r9','r10','r3','r6','r7','r4','r1','r2'], 'fam1', 1 ).
test( 't31', 583, [], [], 'fam1', 1 ).
test( 't32', 375, [], [], 'fam1', 1 ).
test( 't33', 533, ['m9','m1'], [], 'fam1', 1 ).
test( 't34', 271, [], [], 'fam1', 1 ).
test( 't35', 593, [], [], 'fam1', 1 ).
test( 't36', 352, [], [], 'fam1', 1 ).
test( 't37', 202, [], ['r7','r3','r1','r9','r8','r6'], 'fam1', 1 ).
test( 't38', 598, [], [], 'fam1', 1 ).
test( 't39', 237, ['m2','m3','m7','m13','m18'], [], 'fam1', 1 ).
test( 't40', 662, [], [], 'fam1', 1 ).
test( 't41', 612, [], [], 'fam1', 1 ).
test( 't42', 416, [], ['r10','r5','r3','r6','r9','r2'], 'fam1', 1 ).
test( 't43', 383, [], [], 'fam1', 1 ).
test( 't44', 305, [], ['r7','r2','r9','r1','r4','r3','r5','r8','r10','r6'], 'fam1', 1 ).
test( 't45', 683, [], ['r4'], 'fam1', 1 ).
test( 't46', 242, [], ['r6','r8','r1','r9','r10'], 'fam1', 1 ).
test( 't47', 735, ['m13'], [], 'fam1', 1 ).
test( 't48', 121, [], ['r4','r9','r10'], 'fam1', 1 ).
test( 't49', 21, [], ['r1','r8','r10','r9','r5','r2','r6'], 'fam1', 1 ).
test( 't50', 748, [], ['r8','r5','r1','r7','r6'], 'fam1', 1 ).
test( 't51', 69, [], [], 'fam1', 1 ).
test( 't52', 63, [], ['r4','r7','r1','r9','r10','r3'], 'fam1', 1 ).
test( 't53', 784, ['m2','m6'], ['r9','r3','r10','r8','r5','r6','r7'], 'fam1', 1 ).
test( 't54', 446, [], ['r2','r1','r7'], 'fam1', 1 ).
test( 't55', 131, [], [], 'fam1', 1 ).
test( 't56', 288, [], ['r1','r2','r5','r6','r9','r10','r7','r8'], 'fam1', 1 ).
test( 't57', 25, [], ['r7','r6','r4','r2','r1','r3'], 'fam1', 1 ).
test( 't58', 765, ['m18','m10','m20','m14','m7','m9','m8','m6'], ['r8','r4','r9','r3','r5'], 'fam1', 1 ).
test( 't59', 468, [], [], 'fam1', 1 ).
test( 't60', 789, [], ['r7','r10','r9','r3','r2','r8','r5','r4'], 'fam1', 1 ).
test( 't61', 248, [], [], 'fam1', 1 ).
test( 't62', 781, [], [], 'fam1', 1 ).
test( 't63', 228, [], [], 'fam1', 1 ).
test( 't64', 608, [], [], 'fam1', 1 ).
test( 't65', 530, [], ['r1','r7','r3','r8'], 'fam1', 1 ).
test( 't66', 212, [], ['r5','r3','r6','r9','r8'], 'fam1', 1 ).
test( 't67', 342, [], [], 'fam1', 1 ).
test( 't68', 14, [], [], 'fam1', 1 ).
test( 't69', 618, [], [], 'fam1', 1 ).
test( 't70', 199, [], ['r5','r9','r2','r7','r1','r10','r4','r6'], 'fam1', 1 ).
test( 't71', 19, [], [], 'fam1', 1 ).
test( 't72', 492, [], [], 'fam1', 1 ).
test( 't73', 468, [], [], 'fam1', 1 ).
test( 't74', 744, [], [], 'fam1', 1 ).
test( 't75', 612, [], [], 'fam1', 1 ).
test( 't76', 674, [], [], 'fam1', 1 ).
test( 't77', 510, [], [], 'fam1', 1 ).
test( 't78', 585, [], ['r6','r9','r2','r8','r10','r7','r4','r1'], 'fam1', 1 ).
test( 't79', 478, [], ['r5','r2','r7','r8'], 'fam1', 1 ).
test( 't80', 171, [], [], 'fam1', 1 ).
test( 't81', 593, [], [], 'fam1', 1 ).
test( 't82', 77, [], [], 'fam1', 1 ).
test( 't83', 39, ['m2','m11','m20','m8','m14','m15','m10','m12'], ['r2','r7','r8'], 'fam1', 1 ).
test( 't84', 585, ['m17','m3','m7','m10'], [], 'fam1', 1 ).
test( 't85', 581, [], ['r1','r10','r7','r8','r5','r3','r4'], 'fam1', 1 ).
test( 't86', 375, [], ['r9','r7','r6','r8','r3','r1','r4','r2'], 'fam1', 1 ).
test( 't87', 273, [], ['r2','r8','r6'], 'fam1', 1 ).
test( 't88', 649, [], [], 'fam1', 1 ).
test( 't89', 591, [], [], 'fam1', 1 ).
test( 't90', 683, [], [], 'fam1', 1 ).
test( 't91', 212, [], [], 'fam1', 1 ).
test( 't92', 163, [], [], 'fam1', 1 ).
test( 't93', 773, [], [], 'fam1', 1 ).
test( 't94', 569, [], ['r8','r10','r7','r5','r3','r6','r9','r1'], 'fam1', 1 ).
test( 't95', 537, [], ['r5','r6','r9','r10','r1','r4','r7','r2','r8'], 'fam1', 1 ).
test( 't96', 747, [], [], 'fam1', 1 ).
test( 't97', 441, [], [], 'fam1', 1 ).
test( 't98', 185, [], [], 'fam1', 1 ).
test( 't99', 669, ['m6','m15','m1'], ['r4','r9','r1'], 'fam1', 1 ).
test( 't100', 513, [], [], 'fam1', 1 ).

embedded_board( 'm1').
embedded_board( 'm2').
embedded_board( 'm3').
embedded_board( 'm4').
embedded_board( 'm5').
embedded_board( 'm6').
embedded_board( 'm7').
embedded_board( 'm8').
embedded_board( 'm9').
embedded_board( 'm10').
embedded_board( 'm11').
embedded_board( 'm12').
embedded_board( 'm13').
embedded_board( 'm14').
embedded_board( 'm15').
embedded_board( 'm16').
embedded_board( 'm17').
embedded_board( 'm18').
embedded_board( 'm19').
embedded_board( 'm20').

testsetup( 'fam1', 0 ).

resource( 'r1', 1).
resource( 'r2', 1).
resource( 'r3', 1).
resource( 'r4', 1).
resource( 'r5', 1).
resource( 'r6', 1).
resource( 'r7', 1).
resource( 'r8', 1).
resource( 'r9', 1).
resource( 'r10', 1).
